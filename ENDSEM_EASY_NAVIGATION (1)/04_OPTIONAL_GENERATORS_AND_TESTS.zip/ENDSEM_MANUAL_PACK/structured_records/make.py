"""Generate any supported standalone structured-record answer."""
import argparse
from pathlib import Path
from engine import SKINS,CIPHERS,HASHES,SIGNATURES,render
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--skin',choices=SKINS,default='grant')
p.add_argument('--cipher',choices=CIPHERS,default='aes192_cbc')
p.add_argument('--hash',choices=HASHES,default='md5')
p.add_argument('--sig',choices=SIGNATURES,default='rsa_v15')
p.add_argument('--storage',choices=['json','sqlite'],default='json')
p.add_argument('--index',choices=['hmac','siv'],default='hmac')
p.add_argument('--output',default='Structured_Record_Answer.py');p.add_argument('--list',action='store_true')
args=p.parse_args()
if args.list:
 for k,v in dict(skins=SKINS,ciphers=CIPHERS,hashes=HASHES,signatures=SIGNATURES,storage=['json','sqlite'],index=['hmac','siv']).items():print(k,', '.join(v))
else:
 try:code=render(skin=args.skin,cipher=args.cipher,hash=args.hash,sig=args.sig,storage=args.storage,index=args.index)
 except ValueError as error:p.error(str(error))
 path=Path(args.output);path.parent.mkdir(parents=True,exist_ok=True);path.write_text(code);print(path)
