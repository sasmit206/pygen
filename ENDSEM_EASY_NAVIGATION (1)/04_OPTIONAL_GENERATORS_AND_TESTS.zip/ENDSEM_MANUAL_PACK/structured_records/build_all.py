"""Build all tested structured-record variants from one source template."""
import csv,hashlib
from pathlib import Path
from engine import ROOT,SKINS,CIPHERS,HASHES,SIGNATURES,all_core,render,DEFAULT
FIELDS=['path','family','skin','cipher','hash','sig','storage','index','lines','sha256','test_result']
def configurations():
 for choices in all_core():yield 'core',DEFAULT|choices
 for skin in SKINS:
  for storage,index in [('json','siv'),('sqlite','hmac'),('sqlite','siv')]:
   yield 'advanced',DEFAULT|dict(skin=skin,storage=storage,index=index)
def main():
 rows=[]
 for family,c in configurations():
  number=list(SKINS).index(c['skin'])+1
  path=Path('variants')/f'{number:02}_{c["skin"]}'/(Path('core')/c['cipher']/c['hash']/(c['sig']+'.py') if family=='core' else Path('advanced')/f'{c["storage"]}_{c["index"]}.py')
  code=render(**c);(ROOT/path).parent.mkdir(parents=True,exist_ok=True);(ROOT/path).write_text(code)
  rows.append(dict(path=path.as_posix(),family=family,**c,lines=len(code.splitlines()),sha256=hashlib.sha256(code.encode()).hexdigest(),test_result='NOT RUN'))
 assert len(rows)==5224,len(rows)
 with (ROOT/'MANIFEST.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=FIELDS);w.writeheader();w.writerows(rows)
 print('Generated',len(rows),'structured-record variants across',len(SKINS),'stories.')
if __name__=='__main__':main()
