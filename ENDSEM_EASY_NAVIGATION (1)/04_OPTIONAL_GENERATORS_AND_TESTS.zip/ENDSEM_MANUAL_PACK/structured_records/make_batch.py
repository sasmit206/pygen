"""Bounded production of structured-record combinations, optional full-space count."""
import argparse,itertools,json,hashlib
from pathlib import Path
from engine import SKINS,CIPHERS,HASHES,SIGNATURES,render,DEFAULT,valid
p=argparse.ArgumentParser(description=__doc__)
choices={'skin':SKINS,'cipher':CIPHERS,'hash':HASHES,'sig':SIGNATURES,'storage':['json','sqlite'],'index':['hmac','siv']}
for axis,values in choices.items():p.add_argument('--'+axis,choices=values)
p.add_argument('--count',action='store_true');p.add_argument('--limit',type=int,default=25);p.add_argument('--out',type=Path,default=Path('structured_batch'))
args=p.parse_args();options={k:[getattr(args,k)] if getattr(args,k) else list(values) for k,values in choices.items()}
count=0
for h,s in itertools.product(options['hash'],options['sig']):
 if valid(DEFAULT|dict(hash=h,sig=s)):count+=1
for axis in options:
 if axis not in ('hash','sig'):count*=len(options[axis])
print('Valid configurations:',count)
if not args.count:
 if args.limit<1:p.error('--limit must be >=1')
 args.out.mkdir(parents=True,exist_ok=True);rows=[]
 for values in itertools.product(*options.values()):
  c=dict(zip(options,values))
  if not valid(c):continue
  tag=hashlib.sha256(json.dumps(c,sort_keys=True).encode()).hexdigest()[:12]
  name=c['skin']+'_'+c['cipher']+'_'+c['hash']+'_'+c['sig']+'_'+tag+'.py'
  path=args.out/name;code=render(**c)
  if path.exists() and path.read_text()!=code:raise FileExistsError(path)
  path.write_text(code);rows.append(dict(path=name,**c,test_result='NOT RUN'))
  if len(rows)>=args.limit:break
 (args.out/'index.json').write_text(json.dumps(rows,indent=2));print('Written:',len(rows))
