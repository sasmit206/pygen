"""Build standalone endsem programs from small, swappable adapter blocks."""
from pathlib import Path
import json,itertools,random,pprint
ROOT=Path(__file__).resolve().parent
SKINS={
 'voting':('SECURE ELECTRONIC VOTING SYSTEM','Voter','Election Server','Tally Authority','ballot','candidate','constituency','CandidateID','ConstituencyID'),
 'auction':('SEALED BID AGGREGATION','Bidder','Auction Server','Bid Opening Authorities','bid','bid amount','auction','BidAmount','AuctionID'),
 'meter':('SMART METER AGGREGATION','Meter Operator','Billing Server','Billing Authorities','reading','usage','region','UsageUnits','RegionID'),
 'health':('HEALTH SURVEY AGGREGATION','Respondent','Survey Server','Statistics Authorities','response','metric','cohort','MetricValue','CohortID'),
 'payroll':('PAYROLL TOTALS','Employee','Payroll Server','Payroll Authorities','submission','salary units','department','SalaryUnits','DepartmentID'),
 'marks':('EXAM MARKS AGGREGATION','Examiner','Results Server','Results Authorities','mark record','mark','course','Mark','CourseID'),
 'donations':('DONATION AGGREGATION','Donor','Campaign Server','Campaign Authorities','donation','amount','campaign','Amount','CampaignID'),
 'supply':('SUPPLY CHAIN QUANTITY AGGREGATION','Supplier','Inventory Server','Inventory Authorities','shipment','quantity','warehouse','Quantity','WarehouseID'),
 'custom':('CUSTOM SECURE AGGREGATION','Submitter','Verification Server','Aggregate Authorities','record','value','group','Value','GroupID')}
CIPHERS=[f'{family}_{mode}' for family in ['aes256','aes128','aes192','des','3des'] for mode in ['cbc','ecb','cfb','ofb','ctr']]
AXES={'skin':list(SKINS),'cipher':CIPHERS,'keywrap':['rsa4096','rsa2048','rsa1024','elgamal','ecc','dh','rabin','ec_elgamal'], 'hash':['sha512','sha256','sha1','md5','sha3_256'],'sig':['elgamal','rsa_v15','rsa_pss','schnorr','dsa','ecdsa'], 'he':['paillier','elgamal','rsa'],'tally':['sample','onehot','product'],'threshold':['additive','shamir'], 'sse':['hmac','deterministic'],'storage':['pickle','json','sqlite'],'timestamp':['signed','plain'],'time':['demo','system','ask']}
DEFAULT={k:v[0] for k,v in AXES.items()}
def valid(c):
    if c['sig'] in ('dsa','ecdsa') and c['hash'] in ('md5','sha1'): return False,'DSA/ECDSA adapters require SHA-256, SHA-512 or SHA3-256.'
    if (c['he']=='paillier') == (c['tally']=='product'): return False,'Paillier uses sample/onehot sums; multiplicative HE requires --tally product.'
    return True,''
def configuration(**options):
    c=DEFAULT|options
    for key,value in c.items():
        if key not in AXES or value not in AXES[key]: raise ValueError(f'Unsupported {key}: {value}')
    okay,reason=valid(c)
    if not okay: raise ValueError(reason)
    return c
def labels(c):
    t=json.loads((ROOT/'templates/text.json').read_text())
    title,client,server,tally,record,value,group,vfield,gfield=SKINS[c['skin']]
    t.update(title='\n'+title,client='\n'+client.upper(),server='\n'+server.upper(),tally='\n'+tally.upper(),client_label=client,server_label=server,tally_label=tally,fields=[vfield,gfield],record_name=record,value_name=value,group_name=group)
    t['value_input']=t.pop('candidate')
    if c['skin']!='voting':
        t.update(cast='Submit '+record,check='Verify '+record,user='User ID (user1/user2/user3/user4): ',value_input=value.capitalize()+' (demo values 1/2/3): ',group=group.capitalize()+' ID: ',record=record.capitalize()+' ID: ',ids=record.capitalize()+' IDs to aggregate (space separated): ',search_mode='Search by 1 '+group.capitalize()+' | 2 Time range: ',accepted='Output '+record+' stored: ID={id}; awaiting server verification',verified='Output '+record+' verification: ACCEPTED',duplicate='Rejected: this user has already submitted a '+record+'.',bounds='Rejected: invalid '+value+' or registered '+group+'.',matches='Output matching '+record+' IDs: {value}',invalid_ids='Select at least two distinct, verified '+record+' IDs.',privacy='Output individual '+record+' values decrypted: NO')
    else: t['privacy']='Output individual Paillier votes decrypted: NO' if c['he']=='paillier' else 'Output individual encrypted votes decrypted: NO'
    if c['skin']!='voting': t['no_total']='Aggregate verified '+record+'s before requesting threshold decryption.'
    t['no_iv']='not used (ECB)'
    if c['timestamp']=='plain': t['timestamp']='Output unsigned clock timestamp: {value}'
    if c['tally']=='product': t['total']='Output decrypted PRODUCT (not sum): {value}'
    return t

def render(**options):
    c=configuration(**options); t=labels(c)
    hashes={'sha512':('SHA512','SHA-512'),'sha256':('SHA256','SHA-256'),'sha1':('SHA1','SHA-1'),'md5':('MD5','MD5'),'sha3_256':('SHA3_256','SHA3-256')}
    if c['cipher'].startswith('aes'): family='aes'; keylen=int(c['cipher'][3:6])//8; mode=c['cipher'].split('_')[1].upper(); cipherlabel=f'AES-{keylen*8}-{mode}'
    else: family='des3' if c['cipher'].startswith('3') else 'des'; keylen=24 if family=='des3' else 8; mode=c['cipher'].split('_')[1].upper(); cipherlabel=('3DES-' if family=='des3' else 'DES-')+mode
    signames={'elgamal':'ElGamal','schnorr':'Schnorr','rsa_v15':'RSA-2048 PKCS1-v1.5','rsa_pss':'RSA-2048 PSS','dsa':'DSA-2048/256','ecdsa':'ECDSA-P256'}
    wrapnames={'rsa4096':'RSA-4096 OAEP/SHA256','rsa2048':'RSA-2048 OAEP/SHA256','rsa1024':'RSA-1024 OAEP/SHA256 (legacy lab)', 'rabin':'Rabin square/CRT with lab key framing','ec_elgamal':'P256 EC-ElGamal byte-point encoding','elgamal':'ElGamal RFC3526-2048','ecc':'P256 ECDH/SHA256/AES-GCM hybrid','dh':'RFC3526-2048 DH/SHA256/AES-GCM'}
    alg={'hash':hashes[c['hash']][1],'cipher':cipherlabel,'wrap':wrapnames[c['keywrap']],'sig':signames[c['sig']],'he':{'paillier':'Paillier additive','elgamal':'ElGamal multiplicative','rsa':'textbook RSA multiplicative'}[c['he']]}
    header='''"""ENDSEM PRACTICE: standalone, Python 3.10+, PyCryptodome + standard library.
Run: python FILE.py [--keygen] [--fast]; --fast is RSA-2048 TEST ONLY.
SOURCE: endsem question + supplied specification + uploaded Labs 1-8 manuals.
ALGORITHMS: @ALGORITHMS@.
Cipher: @PADDING@; CFB uses full-block segments, CTR uses full-block counter.
Demo fixed key/IV; REAL random key and IV per record. AES key stored only wrapped.
Signature digest is the selected record hash; ElGamal reduces it mod(p-1).
Schnorr hashes (commitment, record digest) for its challenge; not a standard encoding.
ElGamal/Schnorr DEMO group p=467; REAL fixed RFC3526 2048-bit group.
HE demo n=3127 or p=467; REAL Paillier/RSA ~2048 bits, ElGamal RFC3526.
THRESHOLD: @THRESHOLD@. Owner shares in separate files, no combined key saved.
SAMPLE_COMPAT sums raw IDs; it counts votes only when EVERY value is 1.
ONE_HOT counts enumerated values (for bids/amounts this is a histogram).
PRODUCT mode is multiplicative and does not compute totals or vote counts.
Minimum aggregate size=2. A single-record request is rejected.
TSA and RBAC are local simulations; no network or OS isolation is claimed.
The verifier decrypts the payload. Index search itself does not decrypt it.
Trusted client assumption: no zero-knowledge proof links HE and payload values.
DEMO keys/nonces are predictable for learning; use REAL mode for random parameters.
MD5/SHA1 and DES/3DES are legacy exercises: use only if named in your question.
Pickle loads only your own local files. Never open an untrusted state pickle.
RUBRIC MAP (supplied topic mapping; photo has no full transcript/mark breakdown):
Writeup: client/server -> cast/check; ED -> seal/open_seal + wrap/unwrap;
DSS -> sign/verify; Hash -> digest; Search -> token/search.
Client outputs: hash/IV/ciphertext/wrapped key/signature/HE/time -> cast.
Server outputs: unwrap/decrypt/signature/hash/TSA/window -> check.
All roles: index update/search -> check/search; encrypted aggregate -> aggregate;
partials + aggregate result + individual-record refusal -> decrypt_total.
Output strings are in Zone 1. These labels are NOT a verified paper transcript.
"""
'''.replace('@ALGORITHMS@','; '.join(alg.values())).replace('@PADDING@','PKCS7 padding for ECB/CBC, no padding for stream modes').replace('@THRESHOLD@','additive n-of-n partial decryption' if c['threshold']=='additive' else 'Shamir t-of-n; reconstructs the private exponent temporarily')
    header=header.replace('Cipher: ',f"Payload key length: {keylen} bytes; DES-family bytes include parity. IV: {'none (ECB)' if mode=='ECB' else str(8 if family in ('des','des3') else 16)+' bytes'}.\nSEARCH: {'HMAC-SHA256 equality/time-bucket tokens' if c['sse']=='hmac' else 'deterministic AES-256-SIV index, SHA512-derived 64-byte key'}.\nTIMESTAMP: {'local RSA-2048 PKCS1-v1.5/SHA256 signature on SHA512(envelope) plus time' if c['timestamp']=='signed' else 'unsigned local clock'}.\nSTORAGE: {c['storage']}; per-owner keys/shares in separate JSON files.\nCipher: " )
    if c['keywrap']=='rabin': header=header.replace('ALGORITHMS:', 'Rabin uses four-root CRT and a redundant frame; educational framing, not standard CCA padding.\nALGORITHMS:')
    if c['keywrap']=='ec_elgamal': header=header.replace('ALGORITHMS:', 'EC-ElGamal encrypts byte+1 times P256 generator; small lookup decoding is educational.\nALGORITHMS:')
    imports='''import hashlib, hmac, json, math, pickle, secrets, sqlite3, sys
from pathlib import Path
from datetime import datetime, timedelta, timezone
from Crypto.Cipher import AES, DES, DES3, PKCS1_OAEP
from Crypto.Hash import SHA256, SHA512, SHA1, MD5, SHA3_256
from Crypto.PublicKey import RSA, DSA, ECC
from Crypto.Signature import pkcs1_15, pss, DSS
from Crypto.Util.Padding import pad, unpad
from Crypto.Util.number import getPrime
'''
    zone1='\n# QUICK EDIT MAP (read this before adapting a question):\n# Zone 1 TEXT: rename the story, roles, prompts and the TWO submitted fields.\n# Zone 2 ACCOUNTS/GROUPS: edit IDs, passwords, and registered group numbers.\n# Zone 4: set demo values, time window, aggregation limits, and storage policy.\n# Zone 5: menu labels and which role may run each action.\n# Zone 6: crypto adapters; choose an algorithm variant instead of renaming its label.\n# Zone 7: cast -> check -> search -> aggregate -> decrypt_total is the data flow.\n# For an ID + free-text description + numeric amount, start with Grant_Style.\n# After changing crypto/settings, save under a NEW .py filename for fresh state.\n# ================= ZONE 1: SKIN / ALL USER-VISIBLE TEXT =================\n# Edit TEXT values for wording; fields are the two serialized numeric/group keys.\n# Renaming fields is safe here because Zone 7 reads these labels dynamically.\nTEXT = '+pprint.pformat(t,sort_dicts=False,width=120)+'\nALGORITHMS = '+repr(alg)+'\n'
    prefix='voter' if c['skin']=='voting' else 'user'
    accounts={prefix+str(i):('123','client') for i in range(1,5)}|{'server':('123','server'),'authority1':('123','tally'),'authority2':('123','tally'),'authority3':('123','tally')}
    zone2='\n# ================= ZONE 2: ACCOUNTS / ROLES =================\n# ACCOUNTS maps login -> (demo password, role); GROUPS maps login -> group ID.\n# Keep GROUPS IDs consistent with the values users will submit.\nACCOUNTS = '+repr(accounts)+'\nGROUPS = '+repr({prefix+str(i):101+(i-1)%2 for i in range(1,5)})+"\nROLE, LOGIN = None, None\nREQUIRE_LOGIN = False  # True: authenticate before entering each role menu.\n"
    zone3='\n# ================= ZONE 3: KEYS / PARAMETERS =================\n'+(ROOT/'templates/parameters.py.txt').read_text()+"IST = timezone(timedelta(hours=5, minutes=30))\nFORMAT = '%d-%m-%Y %H:%M:%S IST'\nFAST = '--fast' in sys.argv  # Test-only RSA-2048 override.\n"
    zone4=f'''
# ================= ZONE 4: FEATURE FLAGS =================
# Adapt VALUES, START/END, and MIN_AGGREGATE_SIZE to the paper's example.
# Keep TALLY_MODE and HE compatible: Paillier sums; ElGamal/RSA multiply.
# A different cipher/hash/signature requires the matching generated variant.
DEMO_MODE = True  # False: random keys/IVs, large HE groups, live window.
TALLY_MODE = { {'sample':'SAMPLE_COMPAT','onehot':'ONE_HOT','product':'PRODUCT'}[c['tally']]!r}  # Sum IDs, per-value histogram, or multiplicative product.
THRESHOLD_MODE = {c['threshold']!r}  # additive or shamir; see header.
AUTHORITIES = 2  # Number of share holders; add accounts in Zone 2 when increasing.
QUORUM = 2  # additive requires all n; Shamir supports 2 <= t <= n.
TSA_SIGNED = {c['timestamp']=='signed'}  # False: unauthenticated clock, labelled explicitly.
TIME_SOURCE = {c['time']!r}  # demo, system, ask; REAL mode forces system if still demo.
START = '03-11-2025 09:00:00 IST'  # Illustrative demo window, not a paper fact.
END = '03-11-2025 17:00:00 IST'  # REAL mode uses now-5 minutes to now+1 hour.
DEMO_LATE = False  # True: intentionally submit after the window.
SEARCH_BUCKET_MINUTES = 1  # Positive integer token granularity.
SEARCH_RANGE = True  # False: allow equality lookup only.
ONE_PER_USER = True  # Reject repeat submissions from the same account.
REVOKED_USERS = []  # Add account IDs to reject new and existing submissions.
VALUES = [1, 2, 3]  # Enumerated candidates, bids, units, or marks for the exercise.
FROM_FILE = False  # True: read exact bytes with the two Zone-1 field names.
MIN_AGGREGATE_SIZE = 2  # Prevent individual-record decryption through the aggregate menu.
STORAGE = {c['storage']!r}  # pickle, json or sqlite; keys always separate owner JSON files.
DATA_DIR = Path(__file__).with_suffix('')  # Own folder; do not reuse after changing crypto/flags.
'''
    zone5='''
# ================= ZONE 5: MENUS / PERMISSIONS AS DATA =================
# Reorder menu items here; action names must match Zone 7 functions below.
# PERMISSIONS controls the role check inside each action, not just display.
MENUS = {'main':[('client_label','client'),('server_label','server'),('tally_label','tally'),('exit',None)],
         'client':[('cast','cast'),('back',None)], 'server':[('check','check'),('search','search'),('back',None)],
         'tally':[('aggregate','aggregate'),('decrypt','decrypt_total'),('back',None)]}
PERMISSIONS = {'cast':['client'],'check':['server'],'search':['server'],'aggregate':['tally'],'decrypt_total':['tally']}
# ================= ZONE 6: INDEPENDENT CRYPTOGRAPHIC ADAPTERS =================
'''
    blocks=['hash','cipher','keywrap_rsa' if c['keywrap'].startswith('rsa') else 'keywrap_rabin' if c['keywrap']=='rabin' else 'keywrap_ec_elgamal' if c['keywrap']=='ec_elgamal' else 'keywrap_group','signature_group' if c['sig'] in ('elgamal','schnorr') else 'signature_library','he','threshold','search','time']
    adapters='\n'.join((ROOT/'adapters'/f'{b}.py.txt').read_text() for b in blocks)
    repl={'@HASH_MODULE@':hashes[c['hash']][0],'@CIPHER_CONFIG@':repr((family,keylen,mode)),'@RSA_BITS@':c['keywrap'][3:] if c['keywrap'].startswith('rsa') else '4096','@TRANSPORT@':repr(c['keywrap']),'@SIG_KIND@':repr(c['sig']),'@HE_KIND@':repr(c['he']),'@SSE_KIND@':repr(c['sse'])}
    for old,new in repl.items(): adapters=adapters.replace(old,new)
    core=(ROOT/'templates/core.py.txt').read_text().replace("ask('candidate')","ask('value_input')")
    return header+imports+zone1+zone2+zone3+zone4+zone5+adapters+'\n'+core

def curated_profiles(count=60):
    profiles=[{k:DEFAULT[k] for k in ('cipher','hash','sig')}]
    allprofiles=[dict(zip(('cipher','hash','sig'),v)) for v in itertools.product(CIPHERS,AXES['hash'],AXES['sig']) if valid(DEFAULT|dict(zip(('cipher','hash','sig'),v)))[0]]
    random.Random(3141).shuffle(allprofiles)
    for axis in ('cipher','hash','sig'):
        for value in AXES[axis]:
            if not any(p[axis]==value for p in profiles): profiles.append(next(p for p in allprofiles if p[axis]==value and p not in profiles))
    for p in allprofiles:
        if len(profiles)>=count: break
        if p not in profiles: profiles.append(p)
    return profiles
