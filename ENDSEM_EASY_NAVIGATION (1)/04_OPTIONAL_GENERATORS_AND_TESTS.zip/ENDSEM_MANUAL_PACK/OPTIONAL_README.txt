Run python build_all.py in this folder to recreate all variants, then python test_all.py and python structured_records/test_all.py.
