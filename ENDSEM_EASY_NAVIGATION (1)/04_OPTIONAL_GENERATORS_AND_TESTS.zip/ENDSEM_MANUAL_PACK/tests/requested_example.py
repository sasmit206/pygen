"""Run the exact on-demand configuration named in the user's specification."""
from pathlib import Path
import sys,json
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from engine import render,ROOT
from test_all import exercise
config={'skin':'auction','cipher':'aes128_ctr','keywrap':'rsa2048','hash':'sha256','sig':'schnorr','he':'paillier','tally':'onehot','threshold':'shamir','sse':'hmac','storage':'sqlite'}
output,module=exercise(render(**config),fast=False)
assert 'Output counts by bid amount: {1: 1, 2: 1, 3: 0}' in output
result={'case':'exact_requested_auction_generator_example','status':'PASS','config':config}
(ROOT/'tests/requested_example_result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
