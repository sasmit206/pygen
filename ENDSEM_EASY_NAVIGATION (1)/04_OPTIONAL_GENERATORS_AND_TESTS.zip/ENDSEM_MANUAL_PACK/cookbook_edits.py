"""Exact reproducible cookbook transformations, also exercised by test_all.py."""
from engine import render

def substitute(old,new):
    def apply(code):
        assert old in code,old
        return code.replace(old,new,1)
    return apply

def edits():
    return {
     '01_new_story':lambda code:render(skin='auction'),
     '02_usernames':lambda code:code.replace('voter1','learner1'),
     '03_cipher':lambda code:render(cipher='aes128_ctr'),
     '04_hash':lambda code:render(hash='sha256'),
     '05_signature':lambda code:render(sig='schnorr'),
     '06_key_transport':lambda code:render(keywrap='dh'),
     '07_he_product':lambda code:render(he='elgamal',tally='product'),
     '08_window':substitute("START = '03-11-2025 09:00:00 IST'","START = '03-11-2025 10:00:00 IST'"),
     '09_auditor':lambda code:code.replace('ROLE, LOGIN = None, None',"ACCOUNTS['auditor']=('123','audit_label')\nROLE, LOGIN = None, None").replace("('exit',None)]", "('audit_label','audit_label'),('exit',None)]",1).replace("# ================= ZONE 6", "MENUS['audit_label']=[('audit','audit_status'),('back',None)]\nPERMISSIONS['audit_status']=['audit_label']\n# ================= ZONE 6",1),
     '10_revocation':substitute('REVOKED_USERS = []',"REVOKED_USERS = ['voter3']"),
     '11_allow_repeat':substitute('ONE_PER_USER = True','ONE_PER_USER = False'),
     '12_range_bucket':substitute('SEARCH_BUCKET_MINUTES = 1','SEARCH_BUCKET_MINUTES = 15'),
     '13_keyword_menu':lambda code:code.replace('SEARCH_RANGE = True','SEARCH_RANGE = False').replace("'search_mode': 'Search by 1 Constituency | 2 Time range: '","'search_mode': 'Search by 1 Constituency (keyword): '"),
     '14_multi_value_onehot':lambda code:render(tally='onehot').replace('VALUES = [1, 2, 3]','VALUES = [1, 2, 3, 4]').replace('Candidate ID (1/2/3):','Candidate ID (1/2/3/4):'),
     '15_shamir_2_of_3':lambda code:render(threshold='shamir').replace('AUTHORITIES = 2','AUTHORITIES = 3'),
     '16_json_storage':lambda code:render(storage='json'),
     '17_sqlite_storage':lambda code:render(storage='sqlite'),
     '18_file_input':substitute('FROM_FILE = False','FROM_FILE = True'),
     '19_login':substitute('REQUIRE_LOGIN = False','REQUIRE_LOGIN = True'),
     '20_additive_3_of_3':lambda code:code.replace('AUTHORITIES = 2','AUTHORITIES = 3').replace('QUORUM = 2','QUORUM = 3')}

def exercise_edit(name,code,fast):
    # Most edits run the complete baseline scenario. Features changing input or
    # expected rejection need their own explicitly scripted workflow below.
    import sys,contextlib,io,tempfile,copy
    from pathlib import Path
    from unittest.mock import patch
    t=sys.modules.get('__main__')
    if not hasattr(t,'exercise'):
        import test_all as t
    simple={'01_new_story','02_usernames','03_cipher','04_hash','05_signature','06_key_transport','07_he_product','08_window','12_range_bucket','14_multi_value_onehot','15_shamir_2_of_3','16_json_storage','17_sqlite_storage'}
    if name in simple: t.exercise(code,fast=fast);return
    m=t.module(code);m.FAST=fast
    with tempfile.TemporaryDirectory() as folder,contextlib.redirect_stdout(io.StringIO()),patch.object(t.DSA,'generate',t.cached_dsa):
        m.DATA_DIR=Path(folder);m.rsa_key=lambda label,bits:t.cached_rsa(m,label,bits);m.setup();users=list(m.GROUPS)
        if name=='09_auditor':
            with patch('builtins.input',side_effect=['4','1','2','5']):m.main()
            t.rejected(lambda:t.action(m,'cast','audit_label'),m.TEXT['denied']);return
        if name=='10_revocation':
            t.rejected(lambda:t.action(m,'cast','client',['voter3']),m.TEXT['revoked']);return
        if name=='19_login':
            session=['1','voter1','wrong','1','voter1','123','1','1','101','2','4']
            with patch('builtins.input',side_effect=session):m.main()
            assert len(m.STATE['records'])==1 and m.ROLE is None and m.LOGIN is None;return
        for i in range(2):
            if name=='18_file_input':
                path=Path(folder)/f'input{i}.txt';path.write_bytes(f'CandidateID=1;ConstituencyID={101+i}'.encode());answers=[users[i],str(path)]
            else:answers=[users[0] if name=='11_allow_repeat' else users[i],'1',str(101 if name=='11_allow_repeat' else 101+i)]
            t.action(m,'cast','client',answers);t.action(m,'check','server',[str(i+1)])
        if name=='13_keyword_menu':
            assert t.action(m,'search','server',['1','101'])==[1]
            t.rejected(lambda:t.action(m,'search','server',['2']),m.TEXT['bad'])
        t.action(m,'aggregate','tally',['1 2'])
        owners='1 2 3' if name=='20_additive_3_of_3' else '1 2'
        assert t.action(m,'decrypt_total','tally',[owners]+['123']*len(owners.split()))==[2]
